# Discord-Token-Generator
Token generator written in python to make "discord accounts" while joining them in a server.

# How to use

To use this you have to purchase a capmonster key from capmonster's official website (I recommend not using third party who resell the key).
Place the key on data/config.json to the "capmonster" value.
Take your invite code for example
https://discord.gg/cheapboost
make it cheapboost <-
go to data/proxies.txt and put your proxies on `user:pass@ip:port` format. (i recommend using kocerroxy or litespeed residential proxies)

# Info

This code is meant to be used in a educational manner and not for harming others. This code is solely based on concept of the Account generation. This can be patched by discord anytime.
I am not responsible for any harm caused by this tool. The Tool is just shared by me for Saving time finding it!

# Contact

Discord : Shaded#2065
Server : https://discord.gg/cheapboost
